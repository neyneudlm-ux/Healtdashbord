import React, { useState } from 'react';
import { X, Download, Github, CheckCircle2, ArrowRight, ExternalLink, Copy, Check, FolderArchive } from 'lucide-react';

interface GithubUploadGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const GithubUploadGuideModal: React.FC<GithubUploadGuideModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [downloaded, setDownloaded] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  if (!isOpen) return null;

  const handleDownloadZip = () => {
    const link = document.createElement('a');
    link.href = '/health-screening-dashboard.zip';
    link.download = 'health-screening-dashboard.zip';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setDownloaded(true);
  };

  const shareUrl = "https://ais-pre-2ou2vode33idfdgmro3syk-375221460268.asia-southeast1.run.app";

  const handleCopyLink = () => {
    navigator.clipboard.writeText(shareUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl max-w-2xl w-full border border-[#D5E1D3] shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Header */}
        <div className="bg-[#1E2E23] text-white p-4 sm:p-5 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-white">
              <Github className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg">ดาวน์โหลดโปรเจกต์และวิธีนำขึ้น GitHub</h3>
              <p className="text-xs text-[#BED4C2]">
                ดาวน์โหลดไฟล์โค้ดทั้งหมดเป็น .zip ได้ทันทีที่นี่ และนำขึ้น GitHub ได้ง่ายๆ ใน 3 นาที
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-5 text-xs text-[#203627]">
          
          {/* Step 1: Big Download Button */}
          <div className="p-4 rounded-xl bg-gradient-to-r from-[#F2F7F1] to-[#E9F3E7] border-2 border-[#BCD4BA] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-start gap-3">
              <div className="w-9 h-9 rounded-lg bg-[#3C6446] text-white flex items-center justify-center shrink-0 mt-0.5">
                <FolderArchive className="w-5 h-5" />
              </div>
              <div>
                <span className="font-bold text-sm text-[#1B3021] block">
                  ขั้นตอนที่ 1: ดาวน์โหลดไฟล์โค้ดของเว็บไซต์ (.ZIP)
                </span>
                <span className="text-[#516C5A] block mt-0.5">
                  ระบบได้รวมไฟล์โค้ดทั้งหมด (src, components, package.json ฯลฯ) ไว้ให้พร้อมดาวน์โหลดแล้ว
                </span>
              </div>
            </div>

            <button
              type="button"
              onClick={handleDownloadZip}
              className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-[#3C6446] hover:bg-[#315339] text-white font-bold text-xs shadow-md transition-all active:scale-95 shrink-0"
            >
              <Download className="w-4 h-4" />
              <span>{downloaded ? 'ดาวน์โหลดอีกครั้ง' : 'กดดาวน์โหลดไฟล์ .ZIP'}</span>
            </button>
          </div>

          {downloaded && (
            <div className="p-2.5 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>ดาวน์โหลดไฟล์ <strong>health-screening-dashboard.zip</strong> เรียบร้อยแล้ว! (ตรวจสอบที่โฟลเดอร์ Downloads ในเครื่องคุณ)</span>
            </div>
          )}

          {/* Step 2 & 3: GitHub Instructions */}
          <div className="space-y-3 pt-1">
            <h4 className="font-bold text-sm text-[#1E3324] flex items-center gap-1.5 border-b border-[#E3EDE1] pb-2">
              <Github className="w-4 h-4 text-[#3C6446]" /> ขั้นตอนการนำไฟล์ขึ้น GitHub (ไม่ต้องพิมพ์โค้ด)
            </h4>

            <div className="space-y-2.5 text-xs text-[#3E5745]">
              <div className="flex items-start gap-2.5 p-3 rounded-lg bg-[#FAFBF9] border border-[#DEE8DC]">
                <span className="w-5 h-5 rounded-full bg-[#3C6446] text-white flex items-center justify-center font-bold text-[11px] shrink-0 mt-0.5">1</span>
                <div>
                  <strong className="text-[#1F3325]">แตกไฟล์ (Extract ZIP):</strong> คลิกขวาที่ไฟล์ <code>health-screening-dashboard.zip</code> ที่เพิ่งดาวน์โหลด แล้วเลือก <strong>Extract All (แตกไฟล์ทั้งหมด)</strong>
                </div>
              </div>

              <div className="flex items-start gap-2.5 p-3 rounded-lg bg-[#FAFBF9] border border-[#DEE8DC]">
                <span className="w-5 h-5 rounded-full bg-[#3C6446] text-white flex items-center justify-center font-bold text-[11px] shrink-0 mt-0.5">2</span>
                <div>
                  <strong className="text-[#1F3325]">สร้างที่เก็บโค้ดใหม่บน GitHub:</strong> เปิดเว็บ{' '}
                  <a
                    href="https://github.com/new"
                    target="_blank"
                    rel="noreferrer"
                    className="text-[#2F613B] underline font-semibold inline-flex items-center gap-0.5"
                  >
                    github.com/new <ExternalLink className="w-3 h-3" />
                  </a>{' '}
                  ตั้งชื่อคลังโค้ด เช่น <code>health-screening-dashboard</code> แล้วกดปุ่มสีเขียว <strong>Create repository</strong>
                </div>
              </div>

              <div className="flex items-start gap-2.5 p-3 rounded-lg bg-[#FAFBF9] border border-[#DEE8DC]">
                <span className="w-5 h-5 rounded-full bg-[#3C6446] text-white flex items-center justify-center font-bold text-[11px] shrink-0 mt-0.5">3</span>
                <div>
                  <strong className="text-[#1F3325]">ลากไฟล์วางบนหน้าเว็บ:</strong> ในหน้า GitHub ที่เพิ่งสร้าง ให้คลิกข้อความสีฟ้า <strong>"uploading an existing file"</strong> จากนั้นลากไฟล์ทั้งหมดจากโฟลเดอร์ที่แตก ZIP มาวางลงในหน้าต่าง แล้วกด <strong>Commit changes</strong>
                </div>
              </div>
            </div>
          </div>

          {/* Quick Alternative: Share Direct Live Link */}
          <div className="p-3.5 rounded-xl bg-[#F6FAF5] border border-[#CCDDCB] space-y-2">
            <span className="font-bold text-xs text-[#284931] flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-[#3C6947]" /> สำหรับส่งงานอาจารย์ทันที (ไม่ต้องผ่าน GitHub)
            </span>
            <p className="text-[#4E6857] text-[11px]">
              คุณสามารถคัดลอกลิงก์เว็บไซต์นี้ไปส่งให้อาจารย์หรือเพื่อนเปิดดูได้ทันทีจากทุกอุปกรณ์:
            </p>
            <div className="flex items-center gap-2">
              <input
                type="text"
                readOnly
                value={shareUrl}
                className="w-full bg-white border border-[#CAD8C8] text-[#243B2A] rounded-lg px-2.5 py-1.5 text-xs select-all font-mono"
              />
              <button
                type="button"
                onClick={handleCopyLink}
                className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-[#3C6446] text-white text-xs font-semibold hover:bg-[#315339] shrink-0 transition-colors"
              >
                {copiedLink ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedLink ? 'คัดลอกแล้ว' : 'คัดลอกลิงก์'}</span>
              </button>
            </div>
          </div>

        </div>

        {/* Footer */}
        <div className="p-4 bg-[#FAFBF9] border-t border-[#E3EDE1] flex items-center justify-between">
          <span className="text-[11px] text-[#698471]">
            จัดทำโดย นางสาวนูรฮานีนี ดาแล่หมัน • นักศึกษาเวชระเบียน
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-lg bg-[#3C6446] hover:bg-[#315339] text-white text-xs font-semibold shadow-xs"
          >
            เข้าใจแล้ว / ปิดหน้าต่าง
          </button>
        </div>

      </div>
    </div>
  );
};
